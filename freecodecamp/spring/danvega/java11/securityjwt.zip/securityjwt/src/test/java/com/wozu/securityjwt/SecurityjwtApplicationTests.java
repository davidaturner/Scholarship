package com.wozu.securityjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityjwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
