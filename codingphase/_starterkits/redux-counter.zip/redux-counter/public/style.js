export const background = {
  backgroundColor: "#ffffcc",
  width: "25%",
  textAlign: "center",
};
