export const INCREMENT = "Increment";
export const DECREMENT = "Decrement";
export const RESET = "Reset";
